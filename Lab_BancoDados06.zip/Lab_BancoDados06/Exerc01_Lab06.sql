SELECT nome,sobrenome
	from funcionario
    where cargo like 'Programador%'
	order by nome;

SELECT nome,sobrenome,tempoS
	from funcionario
    where tempoS < 3
    order by tempoS desc,nome;

SELECT nome,sobrenome
	from funcionario
    where nome like 'J%'
    order by nome;

SELECT idFuncionario,nome,sobrenome
	from funcionario
    where cargo like '%sr%'
    order by nome;

SELECT nome,sobrenome,salario*12 as salárioAnual
	from funcionario
    where (salario*12) between 70000 and 90000
    order by salario desc;

SELECT idfuncionario,nome,sobrenome,idade
	from funcionario
	where (sobrenome like 'a%' or sobrenome like 'd%')
    and (idade < 30)
    order by nome;

SELECT idfuncionario, nome, sobrenome, idade
	from funcionario
    order by idade
    limit 4;
    
SELECT idfuncionario, nome, sobrenome, idade
	from funcionario
    order by idade desc
    limit 3;