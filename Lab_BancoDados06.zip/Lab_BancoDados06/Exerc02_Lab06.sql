SELECT nome as Nome_Curso, creditos as Créditos, valor as Preço
		from curso;

SELECT DISTINCT valor
	from curso;

SELECT codigo,nome,valor
	from curso
    where valor between 330 and 400
    order by valor desc;

SELECT nome
 from curso
 where nome like '%Software%';

SELECT nome,valor
	from curso
    where valor <= 300;

SELECT nome,creditos+6
	from curso;

SELECT nome, creditos, valor
	from curso
    where valor > 200
    and creditos = 6;

SELECT codigo,min(valor)
	from curso
    limit 1;

SELECT codigo,nome,creditos,max(valor)
	from curso
    limit 1;
    
SELECT truncate(avg (valor),3) as Valor_medio
	from curso;