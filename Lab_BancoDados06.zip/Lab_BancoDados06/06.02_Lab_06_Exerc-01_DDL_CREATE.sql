/*	LAB_06: Exercício 1
	Cria o Banco de Dados lab_06
	Tabela de funcionário
	Carga dos dados de funcionários */

CREATE DATABASE If not exists lab_06;

use lab_06;

/* Criação da tabela de funcionário*/ 

CREATE TABLE if not exists funcionario
(
	idFuncionario smallint PRIMARY KEY not null,
	nome varchar (20) not null,
	sobrenome varchar (20),
	cargo varchar (20),
	idade smallint,
	tempoS smallint,
	salario decimal (7,2) 
);

/* Carga dos dados */

INSERT into funcionario
	values
		(120, 'Pedro', 'Alcantar', 'Analista Pl.', 29, 3, 6000.00),
		(108, 'João', 'Vieira', 'Programador Sr.', 28, 3, 58000.00),
		(89, 'Marilia', 'Moreira', 'DBA', 30, 5, 7000.00),
		(78, 'Rosana', 'de Carvalho', 'Web Designer', 26, 2, 6000.00),
		(97, 'Antenor', 'Campos Melo', 'Analista Jr.', 30, 4, 5000.00),
		(110, 'Henrique', 'Almeida Brito', 'Analista Sr.', 32, 6, 7590.00),
		(109, 'Patrícia', 'Amorim Barbosa', 'Programadora Pl.', 26, 1, 5000.00),
		(111, 'Demerval', 'de Oliveira', 'Programador Jr.', 22, 2, 4500.00);


/* fim do arquivo */