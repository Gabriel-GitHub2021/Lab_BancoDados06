/*	LAB_06: Exercício 2
	Cria o Banco de Dados (se não existe)
	Tabela de curso
	Carga dos dados de cursos */

CREATE DATABASE If not exists lab_06;

use lab_06;

/* Criação da tabela curso */ 

CREATE TABLE if not exists curso
(
	codigo char (4) PRIMARY KEY not null,
	nome varchar (25) not null,
	creditos smallint, 
	valor decimal (7,2) 
);

/* Carga dos dados */

INSERT into curso
	values
		('10-A', 'Sistemas Operacionais', 6, 200),
		('20-B', 'Redes', 12, 350),
		('10-C', 'Java', 10, 200),
		('30-A', 'Banco de Dados', 10, 300),
		('40-B', 'Computação Gráfica', 6, 250),
		('20-C', 'Orientação a Objeto', 6, 200),
		('11-A', 'Inteligência Artificial', 12, 300),
		('35-C', 'Projeto de Software', 8, 350),
		('56-E', 'Qualidade de Software', 12, 400);

select * from curso;

/* fim do script */ 